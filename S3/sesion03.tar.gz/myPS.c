#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

void error_y_exit (char* msg, int exit_status) {
    
    perror (msg);
    exit (exit_status);
}

void muta_a_PS (char* username) {
    
    execlp ("ps", "ps", "-u", username, (char*)NULL);
    error_y_exit ("Ha fallado la mutacion al ps", 1);
}

int main (int argc, char* argv[]) {
    
    char buff[128];
    int pid;
    pid = fork();
    if (pid == 0) {
        
        sprintf (buff, "HIJO: Soy el proceso %d y el parametro es %s\n", getpid(), argv[1]);
        write (1, buff, strlen(buff));
        muta_a_PS(argv[1]);
    }
    else if (pid < 0) error_y_exit("Error en fork", 1);
    else {
        
        sprintf (buff, "PADRE: Soy el proceso %d\n", getpid());
        write (1, buff, strlen(buff));
    }
    while(1);
}
