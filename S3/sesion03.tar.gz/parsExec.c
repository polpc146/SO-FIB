#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <sys/wait.h>
#include <stdlib.h>

void error_y_exit (char* msg, int exit_status) {
    
    perror (msg);
    exit (exit_status);
}

void muta_a_PS (char* username) {
    
    execlp ("ps", "ps", "-u", username, (char*)NULL);
    error_y_exit ("Ha fallado la mutacion al ps", 1);
}

int main (int argc, char* argv[]) {
    
    int pid;
    for (int i=0; i < 4; ++i) {
        
        pid = fork();
        if (pid == 0) {
            
            switch (i) {
                
                case 0:
                    execlp ("./listaParametros", "listaParametros", "a", "b", (char*)NULL);
                case 1:
                    execlp ("./listaParametros", "listaParametros", (char*)NULL);
                case 2:
                    execlp ("./listaParametros", "listaParametros", "25", "4", (char*)NULL);
                default:
                    execlp ("./listaParametros", "listaParametros", "1024", "hola", "adios", (char*)NULL);
            }
        }
        else if (pid < 0) error_y_exit ("Error en fork", 1);
    }
    while (waitpid (-1, NULL, 0) > 0);
}
