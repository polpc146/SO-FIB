#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define MAX_SIZE 8

// devuleve 0 si la string no es un numero o el numero tiene mas de 8 digitos, devuelve 1 en caso contrario
int esNumero (char *str);

//convierte char en int
unsigned int char2int (char c);

//convierte string en int
int mi_atoi (char *str);

// comprueva que como minimo hayan dos parametros
void usage();
