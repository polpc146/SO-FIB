#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "mis_funciones.h"

int main (int argc, char *argv[]) {
    if (argc < 3) {
        
        usage();
        return 0;
    }
    char buff[128];
    int error = 0;
    int suma = 0;
    for (int i = 1; i < argc; ++i) {


        if (esNumero (argv[i]) == 0) {
            
            sprintf (buff, "Error: el parametro '%s' no es un numero\n", argv[i]);
            error = 1;
            write (1, buff, strlen (buff));
        }
        if (error == 0) {
            
            suma += mi_atoi(argv[i]);
        }
    }
    if (error == 0) {
        
        sprintf (buff, "La suma es %d\n", suma);
        write (1, buff, strlen(buff));
    }
    return 0;
}
