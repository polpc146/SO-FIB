#include "mis_funciones.h"

int esNumero (char *str) {

    if (str == NULL)
    return 0;
    if (*str == '-') ++str;

    int i = 0;
    while (str[i] != '\0') {

        if (!(str[i] >= '0' && str[i] <= '9') || i > MAX_SIZE) return 0;
        ++i;
    }
    return 1;
}

unsigned int char2int (char c) {
    
    return c - '0';
}

int mi_atoi (char *str) {
    
    int neg = 0;
    if (*str == '-') {
        
        ++neg;
        ++str;
    } 
    int n = 0;
    while (*str != '\0') {
        
        n = n*10 + char2int (*str);
        ++str;
    }
    if (neg == 0) return n;
    else return -n;
}

void usage() {
    
    char buff[128];
    sprintf (buff, "Usage:listaParametros arg1 arg2 [arg3..argn]\nEste programa escribe por su salida la suma de  los argumentos que recibe\n");
    write (1, buff, strlen(buff));
}
