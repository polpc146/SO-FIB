#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>

int segundos = 0;

void error_y_exit (char* msg, int exit_status) {
    
    perror (msg);
    exit (exit_status);
}

void alarma (int s) {
    
    if (s == SIGALRM) ++segundos;
    else if (s == SIGUSR1) segundos = 0;
    else {
        
        char buff[256];
        sprintf (buff, "%d segundos\n", segundos);
        write (1, buff, strlen (buff));
    }
}

int main (int argc, char* argv[]) {
    
    struct sigaction sa;
    sigset_t mask;
    
    sigemptyset(&mask);
    sigaddset (&mask, SIGALRM);
    sigaddset (&mask, SIGUSR1);
    sigaddset (&mask, SIGUSR2);
    sigprocmask(SIG_BLOCK, &mask, NULL);
    
    sa.sa_handler = &alarma;
    sa.sa_flags = 0;
    sigfillset(&sa.sa_mask);
    if ((sigaction (SIGALRM, &sa, NULL) < 0) || (sigaction (SIGUSR1, &sa, NULL) < 0) || (sigaction (SIGUSR2, &sa, NULL) < 0)) error_y_exit ("sigaction", 1);
    
    while (1) {
        
        alarm (1);
        sigfillset (&mask);
        sigdelset (&mask, SIGALRM);
        sigdelset (&mask, SIGUSR1);
        sigdelset (&mask, SIGUSR2);
        sigdelset (&mask, SIGINT);
        sigsuspend (&mask);
    }
    exit(1);
}
